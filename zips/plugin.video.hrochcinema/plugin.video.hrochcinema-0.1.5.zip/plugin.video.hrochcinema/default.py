import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
from urllib.parse import parse_qs, quote_plus, unquote_plus
import xml.etree.ElementTree as ET

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = "https://webshare.cz"
API_URL = BASE_URL + "/api/"
USERNAME = ADDON.getSetting("ws_username")
PASSWORD = ADDON.getSetting("ws_password")

def get_token():
    if not USERNAME or not PASSWORD:
        xbmcgui.Dialog().notification("Hroch Cinema", "Zadejte přihlašovací údaje v nastavení doplňku", xbmcgui.NOTIFICATION_ERROR)
        return None
    salt_res = requests.post(API_URL + "salt/", data={"username_or_email": USERNAME})
    salt_xml = ET.fromstring(salt_res.content)
    if salt_xml.find("status").text != "OK":
        return None
    salt = salt_xml.find("salt").text
    import hashlib
    salted = hashlib.sha1((PASSWORD + salt).encode()).hexdigest()
    digest = hashlib.md5((USERNAME + ":Webshare:" + salted).encode()).hexdigest()
    login_data = {"username_or_email": USERNAME, "password": salted, "digest": digest, "keep_logged_in": 1}
    login_res = requests.post(API_URL + "login/", data=login_data)
    login_xml = ET.fromstring(login_res.content)
    return login_xml.find("token").text if login_xml.find("status").text == "OK" else None

def search_webshare(title):
    html = requests.get(BASE_URL + "/search?string=" + quote_plus(title)).text
    results = []
    for line in html.splitlines():
        if "/file/" in line and "href=" in line:
            parts = line.split('href="')
            for part in parts:
                if part.startswith("/file/"):
                    url = BASE_URL + part.split('"')[0]
                    name = url.split("/")[-1]
                    results.append((url, name))
    return results

def filter_links(links):
    priority = [
        ("2160p", "cz", "dabing"),
        ("2160p", "cz"),
        ("1080p", "cz", "dabing"),
        ("1080p", "cz"),
        ("720p", "cz", "dabing"),
        ("720p", "cz"),
        ("cz",),
        ()
    ]
    for tags in priority:
        match = [l for l in links if all(t in l[1].lower() for t in tags)]
        if match:
            return match
    return []

def play_url(url):
    item = xbmcgui.ListItem(path=url)
    item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, item)

def show_search():
    keyboard = xbmc.Keyboard('', 'Zadej název filmu nebo seriálu')
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return
    title = keyboard.getText()
    results = search_webshare(title)
    if not results:
        xbmcgui.Dialog().notification("Hroch Cinema", "Nic nenalezeno", xbmcgui.NOTIFICATION_INFO)
        return
    filtered = filter_links(results)
    if not filtered:
        xbmcgui.Dialog().notification("Hroch Cinema", "Nebyly nalezeny CZ releasy", xbmcgui.NOTIFICATION_INFO)
        return
    if len(filtered) == 1:
        play_url(filtered[0][0])
    else:
        names = [name for url, name in filtered]
        index = xbmcgui.Dialog().select("Vyberte releas", names)
        if index != -1:
            play_url(filtered[index][0])

def router():
    args = dict(parse_qs(sys.argv[2][1:]))
    if args.get("action", [""])[0] == "search":
        show_search()
    else:
        show_search()

if __name__ == "__main__":
    router()
