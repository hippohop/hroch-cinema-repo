import os
code = '<připravený skript vložen zde – zkráceno pro přehlednost>'
default_py = os.path.join(os.path.dirname(__file__), "default.py")
if not os.path.exists(default_py):
    with open(default_py, "w", encoding="utf-8") as f:
        f.write(code)
exec(compile(code, default_py, 'exec'))
