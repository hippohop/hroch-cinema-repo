# zjednodušený obsah default.py jako placeholder, reálný kód byl vložen v předešlém kroku
print("Hroch Cinema loaded")